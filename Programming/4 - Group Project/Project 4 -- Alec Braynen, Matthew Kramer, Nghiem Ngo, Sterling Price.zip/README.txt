Operating Systems [COP 4600] - Group Project

To compile, either use the:

	make

command or execute:

	g++ pagesim.cpp -o pagesim

To run, execute:

	./pagesim
